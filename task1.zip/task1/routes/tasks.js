import express from "express";
const router = express.Router()
import taskModel from "../models/task.js";


//Getting All
router.get('/all', async(req, res) =>{
    try{
        const tasks = await taskModel.find()
        res.json(tasks)
    }
    catch(err){
        res.status(500).json({message : err.message})
    }
})
//Getting One
router.get('/:id', getTask,  (req, res) =>{
    res.send(res.task.description)
})
//Creating One
router.post('/add',  async(req, res) =>{
    const task = await taskModel.create({
        title: req.body.title,
        description: req.body.description,
        status: req.body.status
    })
    res.json(task);
   
})

router.patch('/:id', getTask, async(req, res) =>{
    if(req.body.name != null){
        res.task.name = req.body.name
    }
    if(req.body.description != null){
        res.task.description = req.body.description
    }
    try{
        const updatedDescription = await res.task.save()
        res.json(updatedDescription)
    }
    catch(err){
        res.status(400).json({message : err.message})
    }
})


//Deleting One
router.delete('/:id',getTask, async (req, res) =>{
    try {
        await res.task.remove();
        res.json({message: "task Deleted"})
    }
    catch(err) {
        res.status(500).json({message : err.message})
    }
})

async function getTask(req, res, next){
    let task
    try{
        task = await task.findById(req.params.id)
        if(task == null){
            return res.status(404).json({ message : "Cannot find Task"})
        }
    }catch(err){
        return res.status(500).json({message : err.message})
    }

    res.task = task
    next()
}
export default router;