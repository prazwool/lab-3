import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import router from "./routes/tasks.js";
const app = express();

app.use(express.json());


app.use("/tasks", router);

app.listen(3000, async () => {
  try {
    await mongoose.connect(process.env.DATABASE_URL);
    console.log("connected to database");
  } catch (error) {
    console.log(error);
  }
  console.log("server Started");
});
