import express from 'express';
import categoryModel from '../xyz/Category.js';
const categoryRouter = express.Router();

// Create a new category
categoryRouter.post('/', async (req, res) => {
  try {
    const category = await categoryModel.create(req.body);
    res.json(category);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create category' });
  }
});

// Retrieve a list of all categories
categoryRouter.get('/', async (req, res) => {
  try {
    const categories = await categoryModel.find();
    res.json(categories);
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve categories' });
  }
});

// Retrieve a single category by its id
categoryRouter.get('/:id', async (req, res) => {
  try {
    const category = await categoryModel.findById(req.params.id);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    res.json(category);
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve category' });
  }
});

// Update a category by its id
categoryRouter.put('/:id', async (req, res) => {
  try {
    const category = await categoryModel.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    res.json(category);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update category' });
  }
});

// Delete a category by its id
categoryRouter.delete('/:id', async (req, res) => {
  try {
    const category = await categoryModel.findByIdAndDelete(req.params.id);
    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }
    res.json(category);
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete category' });
  }
});
export default categoryRouter;
