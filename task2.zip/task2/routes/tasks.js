import express from "express";
const tasksRouter = express.Router();
import taskModel from "../xyz/task.js";

// Create a new task
tasksRouter.post('/', async (req, res) => {
  try {
    const task = await taskModel.create(req.body);
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create task' });
  }
});

// Retrieve a list of all tasks
tasksRouter.get('/', async (req, res) => {
  try {
    const tasks = await taskModel.find().populate('category');
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve tasks' });
  }
});

// Retrieve a single task by its id
tasksRouter.get('/:id', async (req, res) => {
  try {
    const task = await taskModel.findById(req.params.id).populate('category');
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve task' });
  }
});

// Update a task by its id
tasksRouter.put('/:id', async (req, res) => {
  try {
    const task = await taskModel.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    }).populate('category');
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update task' });
  }
});

// Delete a task by its id
tasksRouter.delete('/:id', async (req, res) => {
  try {
    const task = await taskModel.findByIdAndDelete(req.params.id).populate('category');
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

export default tasksRouter;
