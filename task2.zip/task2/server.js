import mongoose from "mongoose";
import express from "express";
import tasksRouter from "./routes/tasks.js";
import categoryRouter from "./routes/categories.js";
// Import route files

// Initialize Express app
const app = express();
const port = 3000;

// Configure routes
app.use(express.json());
app.use("/tasks", tasksRouter);
app.use("/categories", categoryRouter);

// Start the server
app.listen(port, async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://hbs:hbs123456@hbs.vbdlaiw.mongodb.net/?retryWrites=true&w=majority"
    );
    console.log("connected to database");
  } catch (error) {
    console.log(error);
  }
  console.log(`Server is running on port ${port}`);
});
